<?php
namespace Santosh\Simpleshipping\Model\Config\Source;

use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;

class CustomAttributeOptions extends AbstractSource
{
    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
        if (null === $this->_options) {
            $this->_options=[
                                ['label' => __('Type11'), 'value' => 1115],
                                ['label' => __('Type21'), 'value' => 2115]
                                
                            ];
        }
        return $this->_options;
    }
}